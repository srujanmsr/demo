import React, { Component } from 'react';
import './SearchJobs.css';

class SearchJobs extends Component {
  render() {
    return (<form  action=""> 

                                
                                
                            </form>);
  }
}

export default SearchJobs;