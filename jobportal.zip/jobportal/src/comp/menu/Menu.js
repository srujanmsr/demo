import React, { Component } from 'react';
//import logo from './logo.svg';
import './Menu.css';
import OpenJobs from '../jobs/OpenJobs';
import SearchJobs from '../search/SearchJobs';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
class SideMenu extends Component {
  render() {
    return (
	  <Router>
            <div>
               <ul>
			   <li><Link to={'/SearchJobs'}>Search</Link></li>
                  <li><Link to={'/OpenJobs'}>Open Jobs</Link></li>
          
               </ul>
               <hr />
               
               <Switch>
                  <Route exact path='/OpenJobs' component={OpenJobs} />
                  
				  <Route exact path='/SearchJobs' component={SearchJobs} />
               </Switch>
            </div>
         </Router>
		 
    );
  }
}

export default SideMenu;

