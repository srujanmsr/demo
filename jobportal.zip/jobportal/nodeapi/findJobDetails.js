var express = require('express');
var app = express();
var url = "mongodb://localhost:27017/jobsDB";
 
var MongoClient = require('mongodb').MongoClient;
 
app.get('/listJobDetails', function (req, res) {
   
MongoClient.connect(url, function(err, db) {
    if (err) throw err;
     var dbo=db.db("jobsDB");

  dbo.collection("jobDetails").find({}).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
res.end( JSON.stringify(result));
    db.close();
  });
console.log("Connected to "+dbo.databaseName);
      
});

      
});

app.listen(8081);
console.log('Running');